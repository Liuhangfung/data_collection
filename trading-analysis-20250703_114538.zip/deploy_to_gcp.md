# 🚀 Deploy Trading Analysis to Google Cloud VM

## Files to Upload to VM

### Core Application Files:
- `stock_fmp_global.go` - Go program for stocks/commodities
- `get_crypto_ccxt.py` - Python program for cryptocurrencies  
- `combine_all_assets.py` - Python combiner with Supabase integration
- `run_daily_ranking.py` - Main runner script
- `go.mod` & `go.sum` - Go dependencies

### Configuration Files:
- `docker-compose.yml` - Docker setup (if needed)
- `Dockerfile` - Container configuration
- `supabase_schema.sql` - Database schema
- `README.md` - Documentation

### Environment Setup:
- `.env` file with your API keys
- `requirements.txt` - Python dependencies

## Step 1: Create Google Cloud VM

### 1.1 Go to Google Cloud Console
- Visit: https://console.cloud.google.com/
- Create new project or select existing project

### 1.2 Create VM Instance
```bash
# Enable Compute Engine API first
gcloud services enable compute.googleapis.com

# Create VM instance
gcloud compute instances create trading-analysis-vm \
    --zone=us-central1-a \
    --machine-type=e2-medium \
    --network-tier=PREMIUM \
    --maintenance-policy=MIGRATE \
    --provisioning-model=STANDARD \
    --scopes=https://www.googleapis.com/auth/cloud-platform \
    --tags=http-server,https-server \
    --image=ubuntu-2204-jammy-v20231128 \
    --image-project=ubuntu-os-cloud \
    --boot-disk-size=20GB \
    --boot-disk-type=pd-standard
```

### 1.3 Alternative: Create via Web Console
1. Go to **Compute Engine > VM instances**
2. Click **Create Instance**
3. Configure:
   - **Name**: `trading-analysis-vm`
   - **Region**: `us-central1`
   - **Zone**: `us-central1-a`
   - **Machine Type**: `e2-medium` (2 vCPU, 4 GB memory)
   - **Boot Disk**: Ubuntu 22.04 LTS, 20 GB
   - **Firewall**: Allow HTTP/HTTPS traffic
4. Click **Create**

## Step 2: Connect to VM

### 2.1 SSH via Web Console
1. Go to **Compute Engine > VM instances**
2. Click **SSH** next to your instance

### 2.2 SSH via Command Line
```bash
gcloud compute ssh trading-analysis-vm --zone=us-central1-a
```

## Step 3: Setup Environment on VM

### 3.1 Update System
```bash
sudo apt update && sudo apt upgrade -y
```

### 3.2 Install Python
```bash
sudo apt install python3 python3-pip python3-venv -y
```

### 3.3 Install Go
```bash
# Download and install Go
wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz

# Add to PATH
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
source ~/.bashrc

# Verify installation
go version
```

### 3.4 Install Git
```bash
sudo apt install git -y
```

## Step 4: Upload Files to VM

### 4.1 Using SCP (from your local machine)
```bash
# Create a tar file of your project
tar -czf trading-analysis.tar.gz *.py *.go *.md go.mod go.sum *.sql

# Upload to VM
gcloud compute scp trading-analysis.tar.gz trading-analysis-vm:~/ --zone=us-central1-a

# Extract on VM
ssh trading-analysis-vm --zone=us-central1-a
tar -xzf trading-analysis.tar.gz
```

### 4.2 Using Git (Alternative)
```bash
# On VM: Clone your repository
git clone https://github.com/yourusername/trading-analysis.git
cd trading-analysis
```

## Step 5: Setup Project Environment

### 5.1 Create Python Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### 5.2 Install Python Dependencies
```bash
pip install requests ccxt python-dotenv psycopg2-binary
```

### 5.3 Setup Go Dependencies
```bash
go mod tidy
```

### 5.4 Create Environment Variables
```bash
# Create .env file
nano .env

# Add your API keys:
FMP_API_KEY=your_fmp_api_key_here
SUPABASE_URL=your_supabase_url_here
SUPABASE_KEY=your_supabase_anon_key_here
```

## Step 6: Test the System

### 6.1 Test Manual Run
```bash
# Activate virtual environment
source venv/bin/activate

# Run the system
python run_daily_ranking.py
```

### 6.2 Verify Database Upload
Check your Supabase dashboard to ensure data was uploaded successfully.

## Step 7: Setup Automated Scheduling (Every 4 Hours)

### 7.1 Create Cron Job Script
```bash
# Create runner script
nano /home/username/run_trading_analysis.sh
```

### 7.2 Add Script Content
```bash
#!/bin/bash
cd /home/username/trading-analysis
source venv/bin/activate
python run_daily_ranking.py >> /home/username/trading_analysis.log 2>&1
```

### 7.3 Make Script Executable
```bash
chmod +x /home/username/run_trading_analysis.sh
```

### 7.4 Setup Cron Job
```bash
# Edit crontab
crontab -e

# Add this line to run every 4 hours
0 */4 * * * /home/username/run_trading_analysis.sh
```

### 7.5 Verify Cron Job
```bash
# List cron jobs
crontab -l

# Check cron service status
sudo systemctl status cron
```

## Step 8: Monitor and Logs

### 8.1 Check Logs
```bash
# View application logs
tail -f /home/username/trading_analysis.log

# View cron logs
sudo tail -f /var/log/cron.log
```

### 8.2 System Monitoring
```bash
# Check disk space
df -h

# Check memory usage
free -h

# Check running processes
ps aux | grep python
```

## Step 9: Firewall & Security

### 9.1 Configure Firewall (if needed)
```bash
# Allow SSH
sudo ufw allow ssh

# Enable firewall
sudo ufw enable
```

### 9.2 Setup Automatic Updates
```bash
# Install unattended upgrades
sudo apt install unattended-upgrades -y

# Configure automatic updates
sudo dpkg-reconfigure -plow unattended-upgrades
```

## Step 10: Backup Strategy

### 10.1 Setup Log Rotation
```bash
# Create logrotate config
sudo nano /etc/logrotate.d/trading-analysis

# Add content:
/home/username/trading_analysis.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 username username
}
```

## Troubleshooting

### Common Issues:
1. **Go not found**: Make sure Go is in PATH
2. **Python modules not found**: Activate virtual environment
3. **API rate limits**: Check your API key limits
4. **Database connection**: Verify Supabase credentials
5. **Cron not running**: Check `sudo systemctl status cron`

### Debug Commands:
```bash
# Test cron job manually
/home/username/run_trading_analysis.sh

# Check environment variables
env | grep -E "(FMP|SUPABASE)"

# Test individual components
python get_crypto_ccxt.py
go run stock_fmp_global.go
```

## Cost Optimization

### 1. VM Scheduling
- Use `gcloud compute instances stop` to stop VM when not needed
- Use `gcloud compute instances start` to start VM
- Consider using Cloud Functions for sporadic runs

### 2. Machine Type
- Start with `e2-micro` (free tier eligible)
- Upgrade to `e2-small` or `e2-medium` if needed

### 3. Storage
- Use standard persistent disk (cheaper than SSD)
- Clean up old log files regularly

---

## Summary

Your trading analysis system will now:
- ✅ Run automatically every 4 hours
- ✅ Fetch global stocks, crypto, and commodities data
- ✅ Upload top 500 assets to Supabase
- ✅ Include company/crypto logos
- ✅ Log all activity for monitoring
- ✅ Handle errors gracefully

The system is production-ready and will provide continuous market data updates to your Supabase database. 