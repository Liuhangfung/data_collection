#!/bin/bash

# 🚀 Trading Analysis VM Setup Script
# This script sets up the complete environment on Google Cloud VM

echo "🚀 Setting up Trading Analysis System on Google Cloud VM"
echo "============================================================"

# Update system
echo "📦 Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python
echo "🐍 Installing Python and pip..."
sudo apt install python3 python3-pip python3-venv git curl -y

# Install Go
echo "🔧 Installing Go..."
if ! command -v go &> /dev/null; then
    echo "📥 Downloading Go..."
    wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
    sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
    rm go1.21.5.linux-amd64.tar.gz
    
    # Add Go to PATH
    echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
    export PATH=$PATH:/usr/local/go/bin
    
    echo "✅ Go installed successfully"
    go version
else
    echo "✅ Go is already installed"
fi

# Create project directory
echo "📁 Setting up project directory..."
mkdir -p ~/trading-analysis
cd ~/trading-analysis

# Create Python virtual environment
echo "🔧 Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
echo "📦 Installing Python dependencies..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
else
    echo "⚠️  requirements.txt not found. Installing basic dependencies..."
    pip install requests ccxt python-dotenv psycopg2-binary
fi

# Setup Go dependencies (if go.mod exists)
echo "📦 Setting up Go dependencies..."
if [ -f "go.mod" ]; then
    go mod tidy
    echo "✅ Go dependencies updated"
else
    echo "⚠️  go.mod not found. Skipping Go dependencies..."
fi

# Create environment file template
echo "📝 Creating environment file template..."
if [ ! -f ".env" ]; then
    cat > .env << 'EOF'
# Trading Analysis Environment Variables
# Replace these with your actual API keys

FMP_API_KEY=your_fmp_api_key_here
SUPABASE_URL=your_supabase_url_here
SUPABASE_KEY=your_supabase_anon_key_here
EOF
    echo "✅ Created .env template. Please edit it with your actual API keys."
else
    echo "✅ .env file already exists"
fi

# Create cron job script
echo "📅 Creating cron job script..."
cat > ~/run_trading_analysis.sh << 'EOF'
#!/bin/bash
cd ~/trading-analysis
source venv/bin/activate
export PATH=$PATH:/usr/local/go/bin
python run_daily_ranking.py >> ~/trading_analysis.log 2>&1
EOF

chmod +x ~/run_trading_analysis.sh
echo "✅ Cron job script created at ~/run_trading_analysis.sh"

# Test the system
echo "🧪 Testing the system..."
source venv/bin/activate
if [ -f "run_daily_ranking.py" ]; then
    echo "✅ Main script found"
    echo "🔧 To test the system, run: python run_daily_ranking.py"
else
    echo "⚠️  run_daily_ranking.py not found. Please upload your files first."
fi

# Setup cron job
echo "📅 Setting up cron job..."
echo "To setup automatic execution every 4 hours:"
echo "1. Edit crontab: crontab -e"
echo "2. Add this line: 0 */4 * * * /home/\$USER/run_trading_analysis.sh"
echo "3. Save and exit"

# Create log rotation config
echo "📝 Creating log rotation configuration..."
sudo tee /etc/logrotate.d/trading-analysis > /dev/null << EOF
/home/$USER/trading_analysis.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 0644 $USER $USER
}
EOF

echo "✅ Log rotation configured"

# Final summary
echo ""
echo "🎉 VM Setup Complete!"
echo "============================================================"
echo "✅ System packages updated"
echo "✅ Python and Go installed"
echo "✅ Virtual environment created"
echo "✅ Dependencies installed"
echo "✅ Cron job script created"
echo "✅ Log rotation configured"
echo ""
echo "📋 NEXT STEPS:"
echo "1. Edit .env file with your API keys: nano .env"
echo "2. Upload your project files if not already done"
echo "3. Test the system: python run_daily_ranking.py"
echo "4. Setup cron job: crontab -e"
echo "5. Add line: 0 */4 * * * /home/$USER/run_trading_analysis.sh"
echo ""
echo "📊 Monitor logs with: tail -f ~/trading_analysis.log"
echo "🔧 Test cron script with: ~/run_trading_analysis.sh"
echo ""
echo "🚀 Your trading analysis system is ready!" 