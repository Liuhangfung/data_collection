-- Global Asset Ranking System - Add Columns to Existing Assets Table
-- Run this SQL in your Supabase SQL Editor to add new columns to your existing assets table

-- Add missing columns to your existing assets table
-- All columns will be added safely (only if they don't already exist)

-- Add new columns to public.assets table
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS ticker VARCHAR(20);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS current_price NUMERIC;
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS previous_close NUMERIC;
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS percentage_change NUMERIC;
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS volume BIGINT DEFAULT 0;
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS primary_exchange VARCHAR(100);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS asset_type VARCHAR(50);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS data_source VARCHAR(50);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS country VARCHAR(100);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS sector VARCHAR(100);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS industry VARCHAR(100);
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS circulating_supply BIGINT DEFAULT 0;
ALTER TABLE public.assets ADD COLUMN IF NOT EXISTS image TEXT;

-- Create indexes for better performance (only if they don't exist)
CREATE INDEX IF NOT EXISTS idx_assets_snapshot_date_rank ON public.assets(snapshot_date, rank);
CREATE INDEX IF NOT EXISTS idx_assets_symbol ON public.assets(symbol);
CREATE INDEX IF NOT EXISTS idx_assets_category ON public.assets(category);
CREATE INDEX IF NOT EXISTS idx_assets_market_cap_raw ON public.assets(market_cap_raw DESC);
CREATE INDEX IF NOT EXISTS idx_assets_snapshot_date ON public.assets(snapshot_date);

-- Add comments to document the new columns being added
COMMENT ON COLUMN public.assets.ticker IS 'Original ticker field (same as symbol)';
COMMENT ON COLUMN public.assets.current_price IS 'Raw current price in USD (numeric)';
COMMENT ON COLUMN public.assets.previous_close IS 'Previous close price in USD';
COMMENT ON COLUMN public.assets.percentage_change IS '24h percentage change (raw numeric)';
COMMENT ON COLUMN public.assets.volume IS 'Trading volume (24h)';
COMMENT ON COLUMN public.assets.primary_exchange IS 'Primary exchange or platform';
COMMENT ON COLUMN public.assets.asset_type IS 'Original asset type field (same as category)';
COMMENT ON COLUMN public.assets.data_source IS 'Data source (fmp, ccxt, coingecko)';
COMMENT ON COLUMN public.assets.country IS 'Country of origin (for stocks)';
COMMENT ON COLUMN public.assets.sector IS 'Business sector (for stocks)';
COMMENT ON COLUMN public.assets.industry IS 'Industry classification (for stocks)';
COMMENT ON COLUMN public.assets.circulating_supply IS 'Circulating supply (for cryptocurrencies)';
COMMENT ON COLUMN public.assets.image IS 'Company/asset logo image URL'; 